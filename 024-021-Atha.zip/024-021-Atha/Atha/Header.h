#define ENABLE_MODULE_FIREBASE_HANDLER
#define ENABLE_MODULE_WHATSAPP_BOT
#define ENABLE_MODULE_TASK_HANDLER
#define ENABLE_MODULE_TIMER_DURATION
#define ENABLE_MODULE_TIMER_TASK
#define ENABLE_MODULE_SERIAL_HARD
#define ENABLE_MODULE_SERIAL_SWAP
#define ENABLE_MODULE_DIGITAL_INPUT
#define ENABLE_MODULE_DIGITAL_OUTPUT
#define ENABLE_MODULE_LCD_MENU
#define ENABLE_MODULE_DATETIME_NTP

#define ENABLE_SENSOR_MODULE
#define ENABLE_SENSOR_MODULE_UTILITY

#include "Kinematrix.h"
#include "Preferences.h"
#include "WiFiManager.h"
#include "ESP32Servo.h"
#include "CustomTimer.h"
// #include "soc/soc.h"
// #include "soc/rtc_cntl_reg.h"

////////// Utility //////////
const char *ntpServer = "pool.ntp.org";
const long gmtOffset_sec = 7 * 3600;  // Offset for WIB (UTC+7)
const int daylightOffset_sec = 0;

WiFiManager wm;
TaskHandle task;
FirebaseModule firebase;
FirebaseAuthentication auth;
TimerTask firebaseTimer(20000);
Preferences preferences;
TimerDuration nebulTimer;
TimerDuration systemDelayTimer;
TimerDuration nebulOffTimer(15000);  // 15000
TimerDuration infusOffTimer(30000);  // 15000
MovingAverageFilter voltageFilter(2000);

////////// Communication //////////
HardSerial usbSerial;

////////// Input Module //////////
DigitalIn buttonDown(36);
DigitalIn buttonOk(39);
DigitalIn irInfus(25);
DigitalIn irNebul(16);

////////// Output Module //////////
DigitalOut buzzer(17);
DigitalOut relay1(26, true);
DigitalOut relay2(27, true);

Servo servo;

LcdMenu menu(0x27, 16, 2);

////////// Global Variable //////////
struct SystemData {
  const int servoDegreeIncrement = 1;
  const int servoMaxDegree = 90;
  int servoDegreeState = 0;
  int servoDegreeOff;
  int servoDegreeOn;
  int isWiFiConnected = 0;
  int firebaseInitData = 0;
  int firebaseState = 0;

  float battVoltage;
  float battPercentage;

  ////////// Infus //////////

  const uint32_t totalInfusTime = 30000000;
  const int totalInfusCapasities = 500;
  int infusRequest = 500;
  int dropPerMinutes = 20;

  uint32_t infusTimeHour;
  uint32_t infusTimeMinute;
  uint32_t infusTotalTimeHour;
  uint32_t infusTotalTimeMinute;
  bool infusUpdateFirebase;
  bool infusSaveFirebase;
  bool infusStopedFirebase;

  uint32_t estimatedTimeConst = 0;
  uint32_t estimatedTime = 0;
  uint32_t totalTime = 0;
  uint16_t infusCount = 0;

  int infusStartStop = 0;
  int infusStartStopBefore = 0;
  int infusResumeStop = 0;
  int infusResumeStopBefore = 0;
  int infusSystemStatus = 0;
  int infusSystemStatusBefore = 0;

  int infusStatus = 0;
  bool infusDrop = false;
  bool infusDropBuzzer = false;
  bool infusBuzzerEnable = true;
  int infusTimerEnable = 0;
  int infusIsExpired = 0;

  unsigned long estimatedHours;
  unsigned long estimatedMinutes;
  unsigned long estimatedSeconds;

  ////////// Nebul //////////

  uint32_t windowStart = 0;
  uint32_t dropPerMinute = 0;
  uint32_t dropCount = 0;
  bool nebulUpdateFirebase;
  bool nebulSaveFirebase;

  unsigned long nebulEstimatedHours;
  unsigned long nebulEstimatedMinutes;
  unsigned long nebulEstimatedSeconds;

  uint32_t nebulTime;
  int nebulStatus = 0;
  int nebulSystemStatus = 0;
  int nebulWhileInfus = 0;
  uint32_t nebulDurationHours = 0;
  uint32_t nebulDurationMinutes = 0;
  uint32_t nebulDurationSeconds = 0;

  uint32_t systemDelayDurationHours = 0;
  uint32_t systemDelayDurationMinutes = 0;
  uint32_t systemDelayDurationSeconds = 10;
};

SystemData var;