#pragma once

#ifndef CUSTOM_TIMER_H
#define CUSTOM_TIMER_H

struct Time {
  int hours;
  int minutes;
  int seconds;
};

class TimeConverter {
public:
  static Time millisecondsToTime(unsigned long milliseconds) {
    Time time;
    time.seconds = (milliseconds / 1000) % 60;
    time.minutes = (milliseconds / 60000) % 60;
    time.hours = milliseconds / 3600000;
    return time;
  }

  static unsigned long timeToMilliseconds(const Time& time) {
    return (time.hours * 3600000UL) + (time.minutes * 60000UL) + (time.seconds * 1000UL);
  }
};

Time getHoursAndMinutes(float jumlahCairan, float tpm) {
  float totalMinutes = (jumlahCairan * 20) / tpm;
  Time time;
  time.hours = (int)totalMinutes / 60;
  time.minutes = (int)totalMinutes % 60;
  float totalSeconds = totalMinutes * 60;
  time.seconds = (int)((totalSeconds - ((int)totalMinutes * 60)));
  return time;
}

#endif  // CUSTOM_TIMER_H