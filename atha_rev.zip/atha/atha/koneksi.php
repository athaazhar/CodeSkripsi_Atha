<?php
$koneksi = mysqli_connect("localhost","root","root","abirawaapps");

//cek koneksi
if (mysqli_connect_errno()){
    echo "Koneksi database gagal : " . mysqli_connect_error();
}
?>