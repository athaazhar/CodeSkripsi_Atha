<?php
// Aktifkan session
session_start();

if($_SESSION['status'] == "login")
{
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>AthaApps - Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">
    <!-- Firebase App (the core Firebase SDK) is always required and must be listed first -->
    <script src="https://www.gstatic.com/firebasejs/8.6.8/firebase-app.js"></script>
    <!-- Add Firebase products that you want to use -->
    <script src="https://www.gstatic.com/firebasejs/8.6.8/firebase-database.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-dark sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- <div class="d-flex justify-content-center align-items-center mt-10">
                <img src="logo.png" width="200">
            </div> -->

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">

                <div class="sidebar-brand-text mx-3">Monitoring Infus dan Nebul <sup></sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="kelolaInfus.php">
                    <i class="fas fa-fw fa-pen"></i>
                    <span>Kelola Infus dan Nebul</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="kelolaPasien.php">
                    <i class="fas fa-fw fa-user"></i>
                    <span>Kelola Pasien</span></a>
            </li>

            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="grafik.php">
                    <i class="fas fa-fw fa-chart-bar"></i>
                    <span>Grafik</span></a>
            </li>

            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <!-- <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div> -->

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"></span>
                                <img class="img-profile rounded-circle"
                                    src="../img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="logout.php" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                    </div>
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h5 mb-0 text-gray-800">Monitoring Infus 001</h1>
                    </div>

                    <div class="row">

                        <div class="col-md-3 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Nama Pasien</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="getNamaPasien"></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Temperature Card -->
                        <div class="col-md-3 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Sisa Waktu Infus</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="getPesentaseInfus"></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clock fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Ph Card -->
                        <!-- <div class="col-md-3 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Tegangan Baterai</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="getTegangan"></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-bolt fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> -->

                        <!-- Kekeruhan Card -->
                        <div class="col-md-3 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Persentase Baterai</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="getPersentaseBaterai"></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-percentage fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Last Update Card -->
                        <div class="col-md-3 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Last Update</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="getLastUpdate"></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-cloud fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <!-- Content Row -->
                    <div class="row">

                        <div class="col-lg-12 mb-4">

                            <!-- Illustrations -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Data Record Infus 001</h6>
                                </div>
                                <div class="card-body">
                                    
                                        <table id="checkout-list" class="list-group"></table>
                                    
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h5 mb-0 text-gray-800">Monitoring Nebul 001</h1>
                    </div>

                    <div class="row">
                        <!-- Temperature Card -->
                        <div class="col-3 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Nama Pasien</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="getNamaPasienNebul"></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Ph Card -->
                        <div class="col-3 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Sisa Waktu</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="getSisaWaktu"></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-water fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Last Update Card -->
                        <div class="col-3 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Status Nebul</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="getStatusNebul"></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-cloud fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Last Update Card -->
                        <div class="col-3 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Last Update</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="getLastUpdateNebul"></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-cloud fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <!-- Content Row -->
                    <div class="row">

                        <div class="col-lg-12 mb-4">

                            <!-- Illustrations -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Data Record Nebul 001</h6>
                                </div>
                                <div class="card-body">
                                    
                                        <table id="nebul-list" class="list-group"></table>
                                    
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; 2024</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="../vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="../js/demo/chart-area-demo.js"></script>
    <script src="../js/demo/chart-pie-demo.js"></script>

    <!-- Firebase Configuration and Initialization -->
<script>
    // Your web app's Firebase configuration
    var firebaseConfig = {
        apiKey: "AIzaSyBH0AunCay59AUa2-2781ArY9XJ-p6GuUs",
        authDomain: "athaapps.firebaseapp.com",
        projectId: "athaapps",
        storageBucket: "athaapps.appspot.com",
        messagingSenderId: "894226660912",
        appId: "1:894226660912:web:e3f48c6e6d05456b6477f5"
    };
    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);

    // Reference to the database
    var database = firebase.database();

    // Listen for changes in Node 1
    var node1Ref = database.ref('/data/1/');
    node1Ref.on('value', (snapshot) => {
    var data = snapshot.val();
    updateNode1(data);
    });

    // Listen for changes in Node 1
    var node2Ref = database.ref('/data_nebul/1/');
    node2Ref.on('value', (snapshot) => {
    var data = snapshot.val();
    updateNode2(data);
    });

    // Function to update Node 1
    function updateNode1(data) {
        if (data) {
        document.getElementById('getPesentaseInfus').innerText = data.persentase_infus || 'N/A';
        document.getElementById('getNamaPasien').innerText = data.nama_pasien || 'N/A';
        document.getElementById('getPersentaseBaterai').innerText = data.persentase_baterai + " %" || 'N/A';
        document.getElementById('getLastUpdate').innerText = data.last_update || 'N/A';
        } else {
        console.error('Node 1 data is null');
        }
    }

    // Function to update Node 2
    function updateNode2(data) {
        if (data) {
        document.getElementById('getNamaPasienNebul').innerText = data.nama_pasien || 'N/A';
        document.getElementById('getSisaWaktu').innerText = data.sisa_waktu || 'N/A';
        document.getElementById('getLastUpdateNebul').innerText = data.last_update || 'N/A';
        document.getElementById('getStatusNebul').innerText = data.status || 'N/A';
        } else {
        console.error('Node 2 data is null');
        }
    }

    // Function to update Check Out list
    function updateCheckOutList(data) {
        var checkoutList = document.getElementById('checkout-list');
        checkoutList.innerHTML = ''; // Clear existing list

        // Create table
        var table = document.createElement('table');
        table.className = 'table table-striped';

        // Create thead element
        var thead = document.createElement('thead');
        var headerRow = document.createElement('tr');

        // Define table headers
        var headers = ['No', 'Datetime', 'Tetes /Menit', 'Total Waktu Pemberian Infus', 'Dosis Pemberian Infus'];
        headers.forEach(headerText => {
            var th = document.createElement('th');
            th.scope = 'col';
            th.innerText = headerText;
            headerRow.appendChild(th);
        });

        thead.appendChild(headerRow);
        table.appendChild(thead);

        // Create tbody element
        var tbody = document.createElement('tbody');

        var counter = 1;
        for (var key in data) {
            if (data.hasOwnProperty(key)) {
                var row = document.createElement('tr');

                var tdCounter = document.createElement('td');
                tdCounter.innerText = counter;
                row.appendChild(tdCounter);

                var tdDateTime = document.createElement('td');
                tdDateTime.innerText = data[key].last_update;
                row.appendChild(tdDateTime);

                var tdEstimasi = document.createElement('td');
                tdEstimasi.innerText = data[key].estimasi + 'TPM';
                row.appendChild(tdEstimasi);

                var tdWaktuBerjalanInfus = document.createElement('td');
                tdWaktuBerjalanInfus.innerText = data[key].sisa_waktu_infus;
                row.appendChild(tdWaktuBerjalanInfus);

                var tdPersentaseInfus = document.createElement('td');
                tdPersentaseInfus.innerText = data[key].persentase_infus;
                row.appendChild(tdPersentaseInfus);

                // var tdTeganganBaterai = document.createElement('td');
                // tdTeganganBaterai.innerText = data[key].tegangan_baterai + ' V';
                // row.appendChild(tdTeganganBaterai);

                // var tdPersentaseBaterai = document.createElement('td');
                // tdPersentaseBaterai.innerText = data[key].persentase_baterai + ' %';
                // row.appendChild(tdPersentaseBaterai);

                // var tdAction = document.createElement('td');

                // // Create delete button
                // var deleteButton = document.createElement('button');
                // deleteButton.className = 'btn btn-danger btn-sm';
                // deleteButton.innerText = 'Delete';
                // deleteButton.setAttribute('data-key', key);
                // deleteButton.addEventListener('click', function() {
                //     var key = this.getAttribute('data-key');
                //     deleteEntry(key);
                // });

                // tdAction.appendChild(deleteButton);
                // row.appendChild(tdAction);

                tbody.appendChild(row);
                counter++;
            }
        }

        table.appendChild(tbody);
        checkoutList.appendChild(table);
    }

    // Function to update Nebul list
    function updateNebulList(data) {
        var checkoutList = document.getElementById('nebul-list');
        checkoutList.innerHTML = ''; // Clear existing list

        // Create table
        var table = document.createElement('table');
        table.className = 'table table-striped';

        // Create thead element
        var thead = document.createElement('thead');
        var headerRow = document.createElement('tr');

        // Define table headers
        var headers = ['No', 'Datetime', 'Total Waktu Pemberian Terapi'];
        headers.forEach(headerText => {
            var th = document.createElement('th');
            th.scope = 'col';
            th.innerText = headerText;
            headerRow.appendChild(th);
        });

        thead.appendChild(headerRow);
        table.appendChild(thead);

        // Create tbody element
        var tbody = document.createElement('tbody');

        var counter = 1;
        for (var key in data) {
            if (data.hasOwnProperty(key)) {
                var row = document.createElement('tr');

                var tdCounter = document.createElement('td');
                tdCounter.innerText = counter;
                row.appendChild(tdCounter);

                var tdDateTime = document.createElement('td');
                tdDateTime.innerText = data[key].last_update;
                row.appendChild(tdDateTime);

                // var tdPersentaseNebul = document.createElement('td');
                // tdPersentaseNebul.innerText = data[key].persentase_nebul + ' %';
                // row.appendChild(tdPersentaseNebul);

                var tdKapasitasNebul = document.createElement('td');
                tdKapasitasNebul.innerText = data[key].sisa_waktu;
                row.appendChild(tdKapasitasNebul);

                // var tdStatusNebul = document.createElement('td');
                // tdStatusNebul.innerText = data[key].status;
                // row.appendChild(tdStatusNebul);

                // var tdAction = document.createElement('td');

                // // Create delete button
                // var deleteButton = document.createElement('button');
                // deleteButton.className = 'btn btn-danger btn-sm';
                // deleteButton.innerText = 'Delete';
                // deleteButton.setAttribute('data-key', key);
                // deleteButton.addEventListener('click', function() {
                //     var key = this.getAttribute('data-key');
                //     deleteEntry(key);
                // });

                // tdAction.appendChild(deleteButton);
                // row.appendChild(tdAction);

                tbody.appendChild(row);
                counter++;
            }
        }

        table.appendChild(tbody);
        checkoutList.appendChild(table);
    }

    // Function to delete an entry
    // function deleteEntry(key) {
    //     Swal.fire({
    //         title: 'Are you sure?',
    //         text: "You won't be able to revert this!",
    //         icon: 'warning',
    //         showCancelButton: true,
    //         confirmButtonColor: '#3085d6',
    //         cancelButtonColor: '#d33',
    //         confirmButtonText: 'Yes, delete it!'
    //     }).then((result) => {
    //         if (result.isConfirmed) {
    //             var entryRef = database.ref('/riwayat_alert/' + key);
    //             entryRef.remove()
    //                 .then(function() {
    //                     Swal.fire(
    //                         'Deleted!',
    //                         'Your entry has been deleted.',
    //                         'success'
    //                     );
    //                 })
    //                 .catch(function(error) {
    //                     Swal.fire(
    //                         'Error!',
    //                         'There was an error deleting your entry: ' + error.message,
    //                         'error'
    //                     );
    //                 });
    //         }
    //     });
    // }

    // Listen for changes in Check Out node
    var checkoutRef = database.ref('/data_record/infus001/');
    checkoutRef.on('value', (snapshot) => {
        var data = snapshot.val();
        updateCheckOutList(data);
    });

    // Listen for changes in Check Out node 2
    var checkout2Ref = database.ref('/data_record_nebul/nebul001/');
    checkout2Ref.on('value', (snapshot) => {
        var data = snapshot.val();
        updateNebulList(data);
    });

</script>

</body>

</html>

<?php
}
else {
    header("location:../index.php");
    exit();
}
?>