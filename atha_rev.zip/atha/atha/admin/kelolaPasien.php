<?php
// Aktifkan session
session_start();

if ($_SESSION['status'] == "login") {
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>AthaApps - Kelola Pasien</title>

    <!-- Custom fonts for this template-->
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">
    <!-- Firebase App (the core Firebase SDK) is always required and must be listed first -->
    <script src="https://www.gstatic.com/firebasejs/8.6.8/firebase-app.js"></script>
    <!-- Add Firebase products that you want to use -->
    <script src="https://www.gstatic.com/firebasejs/8.6.8/firebase-database.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>

<body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-dark sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
                <div class="sidebar-brand-text mx-3">Monitoring Infus dan Nebul<sup></sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="kelolaInfus.php">
                    <i class="fas fa-fw fa-pen"></i>
                    <span>Kelola Infus dan Nebul</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="kelolaPasien.php">
                    <i class="fas fa-fw fa-user"></i>
                    <span>Kelola Pasien</span></a>
            </li>

            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="grafik.php">
                    <i class="fas fa-fw fa-chart-bar"></i>
                    <span>Grafik</span></a>
            </li>

            <hr class="sidebar-divider d-none d-md-block">
        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <div class="topbar-divider d-none d-sm-block"></div>
                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"></span>
                                <img class="img-profile rounded-circle"
                                    src="../img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="logout.php" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>
                    </ul>
                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard Kelola Pasien</h1>
                        <button class="btn btn-primary" onclick="openAddModal()">Add Data</button>
                    </div>

                    <!-- Content Row -->
                    <div class="row">
                        <div class="col-lg-12 mb-4">
                            <!-- Illustrations -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Data Pasien</h6>
                                </div>
                                <div class="card-body">
                                    <table id="checkout-list" class="list-group"></table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; 2024</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->
        </div>
        <!-- End of Content Wrapper -->
    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../js/sb-admin-2.min.js"></script>

    <!-- Firebase Configuration and Initialization -->
    <script>
        // Your web app's Firebase configuration
        var firebaseConfig = {
            apiKey: "AIzaSyBH0AunCay59AUa2-2781ArY9XJ-p6GuUs",
            authDomain: "athaapps.firebaseapp.com",
            projectId: "athaapps",
            storageBucket: "athaapps.appspot.com",
            messagingSenderId: "894226660912",
            appId: "1:894226660912:web:e3f48c6e6d05456b6477f5"
        };
        // Initialize Firebase
        firebase.initializeApp(firebaseConfig);

        // Reference to the database
        var database = firebase.database();

        // Function to update Check Out list
        function updateCheckOutList(data) {
            var checkoutList = document.getElementById('checkout-list');
            checkoutList.innerHTML = ''; // Clear existing list

            // Create table
            var table = document.createElement('table');
            table.className = 'table table-striped';

            // Create thead element
            var thead = document.createElement('thead');
            var headerRow = document.createElement('tr');

            // Define table headers
            var headers = ['#', 'Nomor Pasien', 'Nomor Infus', 'Nomor Nebul', 'Nama Pasien', 'Ruang Pasien', 'Umur', 'Jenis Kelamin', 'Obat Infus', 'Obat Nebul', 'Status', 'Action'];
            headers.forEach(headerText => {
                var th = document.createElement('th');
                th.scope = 'col';
                th.innerText = headerText;
                headerRow.appendChild(th);
            });

            thead.appendChild(headerRow);
            table.appendChild(thead);

            // Create tbody element
            var tbody = document.createElement('tbody');

            var counter = 1;
            for (var key in data) {
                if (data.hasOwnProperty(key)) {
                    var row = document.createElement('tr');

                    var tdCounter = document.createElement('td');
                    tdCounter.innerText = counter;
                    row.appendChild(tdCounter);

                    var tdNomorPasien = document.createElement('td');
                    tdNomorPasien.innerText = data[key].nomor_pasien;
                    row.appendChild(tdNomorPasien);

                    var tdNomorInfus = document.createElement('td');
                    tdNomorInfus.innerText = data[key].nomor_infus;
                    row.appendChild(tdNomorInfus);

                    var tdNomorNebul = document.createElement('td');
                    tdNomorNebul.innerText = data[key].nomor_nebul;
                    row.appendChild(tdNomorNebul);

                    var tdNamaPasien = document.createElement('td');
                    tdNamaPasien.innerText = data[key].nama_pasien;
                    row.appendChild(tdNamaPasien);

                    var tdRuangPasien = document.createElement('td');
                    tdRuangPasien.innerText = data[key].ruang_pasien;
                    row.appendChild(tdRuangPasien);

                    var tdUmur = document.createElement('td');
                    tdUmur.innerText = data[key].umur;
                    row.appendChild(tdUmur);

                    var tdJenisKelamin = document.createElement('td');
                    tdJenisKelamin.innerText = data[key].jenis_kelamin;
                    row.appendChild(tdJenisKelamin);

                    var tdObatInfus = document.createElement('td');
                    tdObatInfus.innerText = data[key].obat_infus;
                    row.appendChild(tdObatInfus);

                    var tdObatNebul = document.createElement('td');
                    tdObatNebul.innerText = data[key].obat_nebul;
                    row.appendChild(tdObatNebul);

                    // var tdTimer = document.createElement('td');
                    // tdTimer.innerText = data[key].timer;
                    // row.appendChild(tdTimer);

                    var tdStatus = document.createElement('td');
                    tdStatus.innerText = data[key].status;
                    row.appendChild(tdStatus);

                    var tdAction = document.createElement('td');

                    // Create update button
                    var updateButton = document.createElement('button');
                    updateButton.className = 'btn btn-primary btn-sm';
                    updateButton.innerText = 'Update';
                    updateButton.setAttribute('data-key', key);
                    updateButton.addEventListener('click', function() {
                        var key = this.getAttribute('data-key');
                        openUpdateModal(key, data[key]);
                    });

                    var deleteButton = document.createElement('button');
                    deleteButton.className = 'btn btn-danger btn-sm ml-2';
                    deleteButton.innerText = 'Delete';
                    deleteButton.setAttribute('data-id', key);
                    deleteButton.addEventListener('click', function () {
                        deleteData(this.getAttribute('data-id'));
                    });

                    tdAction.appendChild(updateButton);
                    tdAction.appendChild(deleteButton);
                    row.appendChild(tdAction);

                    tbody.appendChild(row);
                    counter++;
                }
            }

            table.appendChild(tbody);
            checkoutList.appendChild(table);
        }

        // Function to open add modal
        function openAddModal() {
            // Clear modal data
            document.getElementById('addNomorPasien').value = '';
            document.getElementById('addNomorInfus').value = '';
            document.getElementById('addNomorNebul').value = '';
            document.getElementById('addNamaPasien').value = '';
            document.getElementById('addRuangPasien').value = '';
            document.getElementById('addUmur').value = '';
            document.getElementById('addJenisKelamin').value = '';
            document.getElementById('addObatInfus').value = '';
            document.getElementById('addObatNebul').value = '';
            // document.getElementById('addTimer').value = '';
            document.getElementById('addStatus').value = '';

            // Show modal
            $('#addModal').modal('show');
        }

        // Function to add data
        function addData() {
            var addNomorPasien = document.getElementById('addNomorPasien').value;
            var addNomorInfus = document.getElementById('addNomorInfus').value;
            var addNomorNebul = document.getElementById('addNomorNebul').value;
            var addNamaPasien = document.getElementById('addNamaPasien').value;
            var addRuangPasien = document.getElementById('addRuangPasien').value;
            var addUmur = document.getElementById('addUmur').value;
            var addJenisKelamin = document.getElementById('addJenisKelamin').value;
            var addObatInfus = document.getElementById('addObatInfus').value;
            var addObatNebul = document.getElementById('addObatNebul').value;
            // var addTimer = document.getElementById('addTimer').value;
            var addStatus = document.getElementById('addStatus').value;

            var newEntryRef = database.ref('/pasien/').push();
            newEntryRef.set({
                nomor_pasien: addNomorPasien,
                nomor_infus: addNomorInfus,
                nomor_nebul: addNomorNebul,
                nama_pasien: addNamaPasien,
                ruang_pasien: addRuangPasien,
                umur: addUmur,
                jenis_kelamin: addJenisKelamin,
                obat_infus: addObatInfus,
                obat_nebul: addObatNebul,
                // timer: addTimer,
                status: addStatus
            }).then(function() {
                $('#addModal').modal('hide');
                Swal.fire(
                    'Added!',
                    'Your entry has been added.',
                    'success'
                );
            }).catch(function(error) {
                Swal.fire(
                    'Error!',
                    'There was an error adding your entry: ' + error.message,
                    'error'
                );
            });
        }

        // Fungsi untuk mendapatkan data dari Firebase dan mengisi select options
        function getData() {
            // Mendapatkan data untuk Nomor Infus
            database.ref('data').once('value').then(function (snapshot) {
                var data = snapshot.val();
                console.log('Data fetched for Nomor Infus:', data); // Debug log
                var selectInfus = document.getElementById('addNomorInfus');
                
                if (selectInfus) {
                    for (var key in data) {
                        if (data.hasOwnProperty(key)) {
                            var option = document.createElement('option');
                            option.value = data[key].nama;
                            option.innerText = data[key].nama;
                            selectInfus.appendChild(option);
                        }
                    }
                } else {
                    console.error('Element with id "addNomorInfus" not found'); // Error log
                }
            }).catch(function (error) {
                console.error('Error fetching data for Nomor Infus:', error); // Error log
            });

            // Mendapatkan data untuk Nomor Nebul
            database.ref('data_nebul').once('value').then(function (snapshot) {
                var data = snapshot.val();
                console.log('Data fetched for Nomor Nebul:', data); // Debug log
                var selectNebul = document.getElementById('addNomorNebul');
                
                if (selectNebul) {
                    for (var key in data) {
                        if (data.hasOwnProperty(key)) {
                            var option = document.createElement('option');
                            option.value = data[key].nama;
                            option.innerText = data[key].nama;
                            selectNebul.appendChild(option);
                        }
                    }
                } else {
                    console.error('Element with id "addNomorNebul" not found'); // Error log
                }
            }).catch(function (error) {
                console.error('Error fetching data for Nomor Nebul:', error); // Error log
            });
        }

        // Memanggil fungsi getData saat halaman dimuat
        window.onload = function () {
            getData();
        }

        function fetchNomorInfus() {
            return firebase.database().ref('/data').once('value').then(snapshot => {
                const infusOptions = [];
                snapshot.forEach(childSnapshot => {
                    infusOptions.push({
                        value: childSnapshot.val().nama,
                        label: childSnapshot.val().nama // Adjust this to your data structure
                    });
                });
                return infusOptions;
            });
        }

        function fetchNomorNebul() {
            return firebase.database().ref('/data_nebul').once('value').then(snapshot => {
                const nebulOptions = [];
                snapshot.forEach(childSnapshot => {
                    nebulOptions.push({
                        value: childSnapshot.val().nama,
                        label: childSnapshot.val().nama // Adjust this to your data structure
                    });
                });
                return nebulOptions;
            });
        }

        function openUpdateModal(key, data) {
            // Set modal data
            document.getElementById('updateKey').value = key;
            document.getElementById('updateNomorPasien').value = data.nomor_pasien;
            document.getElementById('updateNamaPasien').value = data.nama_pasien;
            document.getElementById('updateRuangPasien').value = data.ruang_pasien;
            document.getElementById('updateUmur').value = data.umur;
            document.getElementById('updateJenisKelamin').value = data.jenis_kelamin;
            document.getElementById('updateObatInfus').value = data.obat_infus;
            document.getElementById('updateObatNebul').value = data.obat_nebul;
            // document.getElementById('updateTimer').value = data.timer;
            document.getElementById('updateStatus').value = data.status;

            // Fetch and set Nomor Infus options
            fetchNomorInfus().then(infusOptions => {
                const infusSelect = document.getElementById('updateNomorInfus');
                infusSelect.innerHTML = '<option value="">Select Nomor Infus</option>';
                infusOptions.forEach(option => {
                    const optionElement = document.createElement('option');
                    optionElement.value = option.value;  // Set the value correctly
                    optionElement.textContent = option.label;
                    infusSelect.appendChild(optionElement);
                });
                infusSelect.value = data.nama;  // Set the selected value
            });

            // Fetch and set Nomor Nebul options
            fetchNomorNebul().then(nebulOptions => {
                const nebulSelect = document.getElementById('updateNomorNebul');
                nebulSelect.innerHTML = '<option value="">Select Nomor Nebul</option>';
                nebulOptions.forEach(option => {
                    const optionElement = document.createElement('option');
                    optionElement.value = option.value;  // Set the value correctly
                    optionElement.textContent = option.label;
                    nebulSelect.appendChild(optionElement);
                });
                nebulSelect.value = data.nama;  // Set the selected value
            });

            // Show modal
            $('#updateModal').modal('show');
        }

        function updateData() {
            const key = document.getElementById('updateKey').value;
            const nomorPasien = document.getElementById('updateNomorPasien').value;
            const nomorInfus = document.getElementById('updateNomorInfus').value;
            const nomorNebul = document.getElementById('updateNomorNebul').value;
            const namaPasien = document.getElementById('updateNamaPasien').value;
            const ruangPasien = document.getElementById('updateRuangPasien').value;
            const umur = document.getElementById('updateUmur').value;
            const jenisKelamin = document.getElementById('updateJenisKelamin').value;
            const obatInfus = document.getElementById('updateObatInfus').value;
            const obatNebul = document.getElementById('updateObatNebul').value;
            // const timer = document.getElementById('updateTimer').value;
            const status = document.getElementById('updateStatus').value;

            firebase.database().ref('/pasien/' + key).update({
                nomor_pasien: nomorPasien,
                nomor_infus: nomorInfus,
                nomor_nebul: nomorNebul,
                nama_pasien: namaPasien,
                ruang_pasien: ruangPasien,
                umur: umur,
                jenis_kelamin: jenisKelamin,
                obat_infus: obatInfus,
                obat_nebul: obatNebul,
                // timer: timer,
                status: status
            }).then(() => {
                $('#updateModal').modal('hide');
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: 'Data updated successfully!',
                    timer: 2000,
                    showConfirmButton: false
                });
            }).catch(error => {
                console.error("Error updating data: ", error);
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Failed to update data: ' + error.message
                });
            });
        }

        // Function to delete data from Firebase
        function deleteData(id) {
            Swal.fire({
                title: 'Are you sure?',
                text: 'You won\'t be able to revert this!',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    database.ref('pasien/' + id).remove().then(function () {
                        Swal.fire('Deleted!', 'Your data has been deleted.', 'success');
                        getData();
                    }).catch(function (error) {
                        Swal.fire('Error', error.message, 'error');
                    });
                }
            });
        }

        // Listen for changes in Check Out node
        var checkoutRef = database.ref('/pasien/');
        checkoutRef.on('value', (snapshot) => {
            var data = snapshot.val();
            updateCheckOutList(data);
        });

    </script>
    <!-- Add Modal -->
    <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addModalLabel">Add Data Pasien</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group">
                            <label for="addNomorPasien">Nomor Pasien</label>
                            <input type="text" class="form-control" id="addNomorPasien">
                        </div>
                        <div class="form-group">
                            <label for="addNomorInfus">Nomor Infus</label>
                            <select class="form-control" id="addNomorInfus">
                                <option value="">Select Nomor Infus</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="addNomorNebul">Nomor Nebul</label>
                            <select class="form-control" id="addNomorNebul">
                                <option value="">Select Nomor Nebul</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="addNamaPasien">Nama Pasien</label>
                            <input type="text" class="form-control" id="addNamaPasien">
                        </div>
                        <div class="form-group">
                            <label for="addRuangPasien">Ruang Pasien</label>
                            <input type="text" class="form-control" id="addRuangPasien">
                        </div>
                        <div class="form-group">
                            <label for="addUmur">Umur</label>
                            <input type="text" class="form-control" id="addUmur">
                        </div>
                        <div class="form-group">
                            <label for="addJenisKelamin">Jenis Kelamin</label>
                            <input type="text" class="form-control" id="addJenisKelamin">
                        </div>
                        <div class="form-group">
                            <label for="addObatInfus">Obat Infus</label>
                            <input type="text" class="form-control" id="addObatInfus">
                        </div>
                        <div class="form-group">
                            <label for="addObatNebul">Obat Nebul</label>
                            <input type="text" class="form-control" id="addObatNebul">
                        </div>
                        <!-- <div class="form-group">
                            <label for="addTimer">Timer</label>
                            <input type="text" class="form-control" id="addTimer">
                        </div> -->
                        <div class="form-group">
                            <label for="addStatus">Status</label>
                            <input type="text" class="form-control" id="addStatus" placeholder="-">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="addData()">Add</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Update Modal -->
    <div class="modal fade" id="updateModal" tabindex="-1" role="dialog" aria-labelledby="updateModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="updateModalLabel">Update Data Pasien</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                <form>
                        <div class="form-group">
                            <label for="addNomorPasien">Nomor Pasien</label>
                            <input type="text" class="form-control" id="updateNomorPasien">
                        </div>
                        <div class="form-group">
                            <label for="addNomorInfus">Nomor Infus</label>
                            <select class="form-control" id="updateNomorInfus">
                                <option value="">Select Nomor Infus</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="addNomorNebul">Nomor Nebul</label>
                            <select class="form-control" id="updateNomorNebul">
                                <option value="">Select Nomor Nebul</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="updateNamaPasien">Nama Pasien</label>
                            <input type="text" class="form-control" id="updateNamaPasien">
                        </div>
                        <div class="form-group">
                            <label for="updateRuangPasien">Ruang Pasien</label>
                            <input type="text" class="form-control" id="updateRuangPasien">
                        </div>
                        <div class="form-group">
                            <label for="updateUmur">Umur</label>
                            <input type="text" class="form-control" id="updateUmur">
                        </div>
                        <div class="form-group">
                            <label for="updateJenisKelamin">Jenis Kelamin</label>
                            <input type="text" class="form-control" id="updateJenisKelamin">
                        </div>
                        <div class="form-group">
                            <label for="updateObatInfus">Obat Infus</label>
                            <input type="text" class="form-control" id="updateObatInfus">
                        </div>
                        <div class="form-group">
                            <label for="updateObatNebul">Obat Nebul</label>
                            <input type="text" class="form-control" id="updateObatNebul">
                        </div>
                        <!-- <div class="form-group">
                            <label for="updateTimer">Timer</label>
                            <input type="text" class="form-control" id="updateTimer">
                        </div> -->
                        <div class="form-group">
                            <label for="updateStatus">Status</label>
                            <input type="text" class="form-control" id="updateStatus" placeholder="-">
                        </div>
                        <input type="hidden" id="updateKey">
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="updateData()">Update</button>
                </div>
            </div>
        </div>
    </div>
</body>

</html>

<?php
}
else {
    header("location:../index.php");
    exit();
}
?>