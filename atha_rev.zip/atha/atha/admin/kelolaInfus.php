<?php
// Aktifkan session
session_start();

if ($_SESSION['status'] == "login") {
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>AthaApps - Kelola Infus</title>

    <!-- Custom fonts for this template-->
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">
    <!-- Firebase App (the core Firebase SDK) is always required and must be listed first -->
    <script src="https://www.gstatic.com/firebasejs/8.6.8/firebase-app.js"></script>
    <!-- Add Firebase products that you want to use -->
    <script src="https://www.gstatic.com/firebasejs/8.6.8/firebase-database.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>

<body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-dark sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
                <div class="sidebar-brand-text mx-3">Monitoring Infus dan Nebul<sup></sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="kelolaInfus.php">
                    <i class="fas fa-fw fa-pen"></i>
                    <span>Kelola Infus dan Nebul</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="kelolaPasien.php">
                    <i class="fas fa-fw fa-user"></i>
                    <span>Kelola Pasien</span></a>
            </li>

            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="grafik.php">
                    <i class="fas fa-fw fa-chart-bar"></i>
                    <span>Grafik</span></a>
            </li>

            <hr class="sidebar-divider d-none d-md-block">
        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <div class="topbar-divider d-none d-sm-block"></div>
                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"></span>
                                <img class="img-profile rounded-circle"
                                    src="../img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="logout.php" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>
                    </ul>
                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard Kelola Infus dan Nebul</h1>
                        <button class="btn btn-primary" onclick="openAddModal()">Add Data</button>
                    </div>

                    <!-- Content Row -->
                    <div class="row">
                        <div class="col-lg-12 mb-4">
                            <!-- Illustrations -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Data Infus</h6>
                                </div>
                                <div class="card-body">
                                    <table id="checkout-list" class="list-group"></table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="container-fluid">
                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Kelola Nebul</h1>
                        <button class="btn btn-primary" onclick="openAddNebulModal()">Add Data</button>
                    </div>

                    <!-- Content Row -->
                    <div class="row">
                        <div class="col-lg-12 mb-4">
                            <!-- Illustrations -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Data Nebul</h6>
                                </div>
                                <div class="card-body">
                                    <table id="checkin-list" class="list-group"></table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; 2024</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->
        </div>
        <!-- End of Content Wrapper -->
    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../js/sb-admin-2.min.js"></script>

    <!-- Firebase Configuration and Initialization -->
    <script>
        // Your web app's Firebase configuration
        var firebaseConfig = {
            apiKey: "AIzaSyBH0AunCay59AUa2-2781ArY9XJ-p6GuUs",
            authDomain: "athaapps.firebaseapp.com",
            projectId: "athaapps",
            storageBucket: "athaapps.appspot.com",
            messagingSenderId: "894226660912",
            appId: "1:894226660912:web:e3f48c6e6d05456b6477f5"
        };
        // Initialize Firebase
        firebase.initializeApp(firebaseConfig);

        // Reference to the database
        var database = firebase.database();

        // Function to update Check Out list
        function updateCheckOutList(data) {
            var checkoutList = document.getElementById('checkout-list');
            checkoutList.innerHTML = ''; // Clear existing list

            // Create table
            var table = document.createElement('table');
            table.className = 'table table-striped';

            // Create thead element
            var thead = document.createElement('thead');
            var headerRow = document.createElement('tr');

            // Define table headers
            var headers = ['No', 'Nomor Infus', 'Nama Pasien', 'Lokasi Infus', 'Kapasitas Infus', 'Tetes /menit', 'Alert', 'State', 'Status', 'Action'];
            headers.forEach(headerText => {
                var th = document.createElement('th');
                th.scope = 'col';
                th.innerText = headerText;
                headerRow.appendChild(th);
            });

            thead.appendChild(headerRow);
            table.appendChild(thead);

            // Create tbody element
            var tbody = document.createElement('tbody');

            var counter = 1;
            for (var key in data) {
                if (data.hasOwnProperty(key)) {
                    var row = document.createElement('tr');

                    var tdCounter = document.createElement('td');
                    tdCounter.innerText = counter;
                    row.appendChild(tdCounter);

                    var tdNomorInfus = document.createElement('td');
                    tdNomorInfus.innerText = data[key].nama;
                    row.appendChild(tdNomorInfus);

                    var tdNamaPasien = document.createElement('td');
                    tdNamaPasien.innerText = data[key].nama_pasien;
                    row.appendChild(tdNamaPasien);

                    var tdLokasiInfus = document.createElement('td');
                    tdLokasiInfus.innerText = data[key].lokasi;
                    row.appendChild(tdLokasiInfus);

                    var tdKapasitasInfus = document.createElement('td');
                    tdKapasitasInfus.innerText = data[key].kapasitas + ' mL';
                    row.appendChild(tdKapasitasInfus);

                    var tdmlperdetik = document.createElement('td');
                    tdmlperdetik.innerText = data[key].mlperdetik + ' tpm';
                    row.appendChild(tdmlperdetik);

                    var tdAlert = document.createElement('td');
                    tdAlert.innerText = data[key].alert;
                    row.appendChild(tdAlert);

                    var tdState = document.createElement('td');

                    // Create state start button
                    var stateStartButton = document.createElement('button');
                    stateStartButton.className = 'btn btn-success btn-sm';
                    stateStartButton.innerText = 'Start';
                    stateStartButton.setAttribute('data-key', key);
                    stateStartButton.addEventListener('click', function() {
                        var key = this.getAttribute('data-key');
                        updateStateStart(key);
                    });

                    // Create state stop button
                    var stateStopButton = document.createElement('button');
                    stateStopButton.className = 'btn btn-danger btn-sm ml-2';
                    stateStopButton.innerText = 'Stop';
                    stateStopButton.setAttribute('data-key', key);
                    stateStopButton.addEventListener('click', function() {
                        var key = this.getAttribute('data-key');
                        updateStateStop(key);
                    });

                    tdState.appendChild(stateStartButton);
                    tdState.appendChild(stateStopButton);
                    row.appendChild(tdState);

                    var tdStatus = document.createElement('td');

                    // Create status pause button
                    var statusPauseButton = document.createElement('button');
                    statusPauseButton.className = 'btn btn-warning btn-sm';
                    statusPauseButton.innerText = 'Pause';
                    statusPauseButton.setAttribute('data-key', key);
                    statusPauseButton.addEventListener('click', function() {
                        var key = this.getAttribute('data-key');
                        updateStatusPause(key);
                    });

                    // Create status resume button
                    var statusResumeButton = document.createElement('button');
                    statusResumeButton.className = 'btn btn-dark btn-sm ml-2';
                    statusResumeButton.innerText = 'Resume';
                    statusResumeButton.setAttribute('data-key', key);
                    statusResumeButton.addEventListener('click', function() {
                        var key = this.getAttribute('data-key');
                        updateStatusResume(key);
                    });

                    tdStatus.appendChild(statusPauseButton);
                    tdStatus.appendChild(statusResumeButton);
                    row.appendChild(tdStatus);

                    var tdAction = document.createElement('td');

                    // Create update button
                    var updateButton = document.createElement('button');
                    updateButton.className = 'btn btn-primary btn-sm';
                    updateButton.innerText = 'Update';
                    updateButton.setAttribute('data-key', key);
                    updateButton.addEventListener('click', function() {
                        var key = this.getAttribute('data-key');
                        openUpdateModal(key, data[key]);
                    });

                    // Create delete button
                    var deleteButton = document.createElement('button');
                    deleteButton.className = 'btn btn-danger btn-sm ml-2';
                    deleteButton.innerText = 'Delete';
                    deleteButton.setAttribute('data-key', key);
                    deleteButton.addEventListener('click', function() {
                        var key = this.getAttribute('data-key');
                        deleteData(key);
                    });

                    tdAction.appendChild(updateButton);
                    tdAction.appendChild(deleteButton);
                    row.appendChild(tdAction);

                    tbody.appendChild(row);
                    counter++;
                }
            }

            table.appendChild(tbody);
            checkoutList.appendChild(table);
        }

        function updateStateStart(key) {
            // Update the node /data/key/state with value "start" in Firebase
            firebase.database().ref('data/' + key + '/state').set('start')
            .then(() => {
                // Show success message with SweetAlert
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: 'Node state updated to "start" successfully'
                });
            })
            .catch((error) => {
                // Show error message with SweetAlert
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Error updating node state: ' + error.message
                });
            });
        }

        function updateStateStop(key) {
            // Update the node /data/key/state with value "start" in Firebase
            firebase.database().ref('data/' + key + '/state').set('stop')
            .then(() => {
                // Show success message with SweetAlert
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: 'Node state updated to "stop" successfully'
                });
            })
            .catch((error) => {
                // Show error message with SweetAlert
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Error updating node state: ' + error.message
                });
            });
        }

        function updateStatusPause(key) {
            // Update the node /data/key/state with value "start" in Firebase
            firebase.database().ref('data/' + key + '/status').set('pause')
            .then(() => {
                // Show success message with SweetAlert
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: 'Node status updated to "pause" successfully'
                });
            })
            .catch((error) => {
                // Show error message with SweetAlert
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Error updating node status: ' + error.message
                });
            });
        }

        function updateStatusResume(key) {
            // Update the node /data/key/state with value "start" in Firebase
            firebase.database().ref('data/' + key + '/status').set('resume')
            .then(() => {
                // Show success message with SweetAlert
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: 'Node status updated to "resume" successfully'
                });
            })
            .catch((error) => {
                // Show error message with SweetAlert
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Error updating node status: ' + error.message
                });
            });
        }

        function deleteData(key) {
            if (confirm('Are you sure you want to delete this item?')) {
                firebase.database().ref('/data/' + key).remove()
                .then(function() {
                        $('#addModal').modal('hide');
                        Swal.fire(
                            'Deleted!',
                            'Data deleted successfully!',
                            'success'
                        );
                        refreshCheckInList();
                    }).catch(function(error) {
                        Swal.fire(
                            'Error!',
                            'Error Delete Data! ' + error.message,
                            'error'
                        );
                    });
            }
        }

        // Function to open add modal
        function openAddModal() {
            // Clear modal data
            document.getElementById('addLastUpdate').value = '';
            document.getElementById('addPersentaseBaterai').value = '';
            document.getElementById('addPersentaseInfus').value = '';
            document.getElementById('addTeganganBaterai').value = '';
            document.getElementById('addNomorInfus').value = '';
            document.getElementById('addLokasi').value = '';
            document.getElementById('addKapasitas').value = '';
            document.getElementById('addMLPerDetik').value = '';
            document.getElementById('addNamaPasienInfus').value = '';
            document.getElementById('addAlert').value = '';

            // Populate pasien select element
            const pasienSelect = document.getElementById('addNamaPasienInfus');
            pasienSelect.innerHTML = '<option value="">Select Pasien</option>'; // Clear previous options

            // Fetch data from /pasien/ node
            const pasienRef = database.ref('/pasien/');
            pasienRef.once('value', snapshot => {
            const data = snapshot.val();
            for (let key in data) {
                if (data.hasOwnProperty(key)) {
                const option = document.createElement('option');
                option.value = data[key].nama_pasien;
                option.textContent = data[key].nama_pasien; // Assuming 'name' is a property of each pasien
                pasienSelect.appendChild(option);
                }
            }
            });

            // Show modal
            $('#addModal').modal('show');
        }

        // Function to open add modal
        function openAddNebulModal() {
            // Clear modal data
            document.getElementById('addLastUpdate').value = '0000-00-00T00:00:00';
            document.getElementById('addPersentaseNebul').value = '0';
            document.getElementById('addNomorNebul').value = '';
            document.getElementById('addLokasiNebul').value = '';
            document.getElementById('addSetWaktu').value = '';
            document.getElementById('addStatusNebul').value = '-';
            document.getElementById('addSisaWaktu').value = '-';

            // Populate pasien select element
            const pasienSelect = document.getElementById('addNamaPasien');
            pasienSelect.innerHTML = '<option value="">Select Pasien</option>'; // Clear previous options

            // Fetch data from /pasien/ node
            const pasienRef = database.ref('/pasien/');
            pasienRef.once('value', snapshot => {
            const data = snapshot.val();
            for (let key in data) {
                if (data.hasOwnProperty(key)) {
                const option = document.createElement('option');
                option.value = data[key].nama_pasien;
                option.textContent = data[key].nama_pasien; // Assuming 'name' is a property of each pasien
                pasienSelect.appendChild(option);
                }
            }
            });

            // Show modal
            $('#addNebulModal').modal('show');
        }

        // Function to open update modal
        function openUpdateModal(key, data) {
            // Set modal data
            document.getElementById('updateKey').value = key;
            document.getElementById('updateLokasi').value = data.lokasi;
            document.getElementById('updateKapasitas').value = data.kapasitas;
            document.getElementById('updateMLPerDetik').value = data.mlperdetik;

            // Fetch and populate patient options
            var patientSelect = document.getElementById('updateNamaPasienInfus');
            firebase.database().ref('/pasien/').once('value', function(snapshot) {
                patientSelect.innerHTML = '<option value="">Select Pasien</option>';
                snapshot.forEach(function(childSnapshot) {
                    var option = document.createElement('option');
                    option.value = childSnapshot.val().nama_pasien;
                    option.text = childSnapshot.val().nama_pasien;
                    if (childSnapshot.key === data.pasien) {
                        option.selected = true;
                    }
                    patientSelect.appendChild(option);
                });
            });

            // Show modal
            $('#updateModal').modal('show');
        }

        function openUpdateNebulModal(key, data) {
            document.getElementById('updateNomorNebul').value = data.nama;
            document.getElementById('updateLokasiNebul').value = data.lokasi;
            document.getElementById('updateSetWaktu').value = data.set_waktu;
            document.getElementById('updateKeyNebul').value = key;

            // Fetch and populate patient options
            var patientSelect = document.getElementById('updateNamaPasien');
            firebase.database().ref('/pasien/').once('value', function(snapshot) {
                patientSelect.innerHTML = '<option value="">Select Pasien</option>';
                snapshot.forEach(function(childSnapshot) {
                    var option = document.createElement('option');
                    option.value = childSnapshot.val().nama_pasien;
                    option.text = childSnapshot.val().nama_pasien;
                    if (childSnapshot.key === data.pasien) {
                        option.selected = true;
                    }
                    patientSelect.appendChild(option);
                });
            });

            // Show the modal
            $('#updateNebulModal').modal('show');
        }

        // Function to add data
        function addData() {
            // var addEstimasi = document.getElementById('addEstimasi').value;
            var kapasitas = document.getElementById('addKapasitas').value;
            var last_update = document.getElementById('addLastUpdate').value;
            var lokasi = document.getElementById('addLokasi').value;
            var mlperdetik = document.getElementById('addMLPerDetik').value;
            var nomorInfus = document.getElementById('addNomorInfus').value;
            var addNamaPasien = document.getElementById('addNamaPasienInfus').value;
            var persentase_baterai = document.getElementById('addPersentaseBaterai').value;
            var persentase_infus = document.getElementById('addPersentaseInfus').value;
            // var addState = document.getElementById('addState').value;
            // var addStatus = document.getElementById('addStatus').value;
            var tegangan_baterai = document.getElementById('addTeganganBaterai').value;
            var addAlert = document.getElementById('addAlert').value;

            var newEntryRef = database.ref('/data/').push();
            newEntryRef.set({
                estimasi: '-',
                kapasitas: kapasitas,
                last_update: last_update,
                lokasi: lokasi,
                mlperdetik: mlperdetik,
                nama: nomorInfus,
                nama_pasien: addNamaPasien,
                persentase_baterai: persentase_baterai,
                persentase_infus: persentase_infus,
                state: 'idle',
                status: 'stop',
                tegangan_baterai: tegangan_baterai,
                alert: addAlert
                
            }).then(function() {
                $('#addModal').modal('hide');
                Swal.fire(
                    'Added!',
                    'Your entry has been added.',
                    'success'
                );
            }).catch(function(error) {
                Swal.fire(
                    'Error!',
                    'There was an error adding your entry: ' + error.message,
                    'error'
                );
            });
        }

        // Function to add data
        function addDataNebul() {
            var addLastUpdate = document.getElementById('addLastUpdate').value;
            var addPersentaseNebul = document.getElementById('addPersentaseNebul').value;
            var addNomorNebul = document.getElementById('addNomorNebul').value;
            var addLokasiNebul = document.getElementById('addLokasiNebul').value;
            var addSetWaktu = document.getElementById('addSetWaktu').value;
            var addSisaWaktu = document.getElementById('addSisaWaktu').value;
            var addNamaPasien = document.getElementById('addNamaPasien').value;
            var addStatusNebul = document.getElementById('addStatusNebul').value;

            var newEntryRef = database.ref('/data_nebul/').push();
            newEntryRef.set({
                last_update: addLastUpdate,
                persentase_nebul: addPersentaseNebul,
                nama: addNomorNebul,
                lokasi: addLokasiNebul,
                set_waktu: addSetWaktu,
                sisa_waktu: addSisaWaktu,
                nama_pasien: addNamaPasien,
                status: addStatusNebul
            }).then(function() {
                $('#addNebulModal').modal('hide');
                Swal.fire(
                    'Added!',
                    'Your entry has been added.',
                    'success'
                );
            }).catch(function(error) {
                Swal.fire(
                    'Error!',
                    'There was an error adding your entry: ' + error.message,
                    'error'
                );
            });
        }

        // Function to update data
        function updateData() {
            var key = document.getElementById('updateKey').value;
            var lokasi = document.getElementById('updateLokasi').value;
            var kapasitas = document.getElementById('updateKapasitas').value;
            var mlperdetik = document.getElementById('updateMLPerDetik').value;
            var updateNamaPasienInfus = document.getElementById('updateNamaPasienInfus').value;

            var entryRef = database.ref('/data/' + key);
            entryRef.update({
                lokasi: lokasi,
                kapasitas: kapasitas,
                mlperdetik: mlperdetik,
                nama_pasien: updateNamaPasienInfus
            }).then(function() {
                $('#updateModal').modal('hide');
                Swal.fire(
                    'Updated!',
                    'Your entry has been updated.',
                    'success'
                );
            }).catch(function(error) {
                Swal.fire(
                    'Error!',
                    'There was an error updating your entry: ' + error.message,
                    'error'
                );
            });
        }

        function updateDataNebul() {
            var key = document.getElementById('updateKeyNebul').value;
            var nomorNebul = document.getElementById('updateNomorNebul').value;
            var lokasiNebul = document.getElementById('updateLokasiNebul').value;
            var setWaktu = document.getElementById('updateSetWaktu').value;
            var namaPasien = document.getElementById('updateNamaPasien').value;

            // Update data in Firebase
            firebase.database().ref('/data_nebul/' + key).update({
                nama: nomorNebul,
                lokasi: lokasiNebul,
                set_waktu: setWaktu,
                nama_pasien: namaPasien
            }).then(function() {
                $('#updateNebulModal').modal('hide');
                Swal.fire(
                    'Updated!',
                    'Your entry has been updated.',
                    'success'
                );
            }).catch(function(error) {
                Swal.fire(
                    'Error!',
                    'There was an error updating your entry: ' + error.message,
                    'error'
                );
            });
        }

        // Listen for changes in Check Out node
        var checkoutRef = database.ref('/data/');
        checkoutRef.on('value', (snapshot) => {
            var data = snapshot.val();
            updateCheckOutList(data);
        });

        function updateCheckInList(data) {
            var checkinList = document.getElementById('checkin-list');
            checkinList.innerHTML = ''; // Clear existing list

            // Create table
            var table = document.createElement('table');
            table.className = 'table table-striped';

            // Create thead element
            var thead = document.createElement('thead');
            var headerRow = document.createElement('tr');

            // Define table headers
            var headers = ['No', 'Nomor Nebul', 'Nama Pasien', 'Lokasi Nebul', 'Set Waktu', 'Persentase Nebul', 'Status Nebul', 'State', 'Action'];
            headers.forEach(headerText => {
                var th = document.createElement('th');
                th.scope = 'col';
                th.innerText = headerText;
                headerRow.appendChild(th);
            });

            thead.appendChild(headerRow);
            table.appendChild(thead);

            // Create tbody element
            var tbody = document.createElement('tbody');

            var counter = 1;
            for (var key in data) {
                if (data.hasOwnProperty(key)) {
                    var row = document.createElement('tr');

                    var tdCounter = document.createElement('td');
                    tdCounter.innerText = counter;
                    row.appendChild(tdCounter);

                    var tdNomorNebul = document.createElement('td');
                    tdNomorNebul.innerText = data[key].nama;
                    row.appendChild(tdNomorNebul);

                    var tdNamaPasien = document.createElement('td');
                    tdNamaPasien.innerText = data[key].nama_pasien;
                    row.appendChild(tdNamaPasien);

                    var tdLokasiNebul = document.createElement('td');
                    tdLokasiNebul.innerText = data[key].lokasi;
                    row.appendChild(tdLokasiNebul);

                    var tdSetWaktu = document.createElement('td');
                    tdSetWaktu.innerText = data[key].set_waktu;
                    row.appendChild(tdSetWaktu);

                    var tdPersentaseNebul = document.createElement('td');
                    tdPersentaseNebul.innerText = data[key].persentase_nebul + ' %';
                    row.appendChild(tdPersentaseNebul);

                    var tdStatusNebul = document.createElement('td');
                    tdStatusNebul.innerText = data[key].status;
                    row.appendChild(tdStatusNebul);

                    var tdStateNebul = document.createElement('td');

                    // Create state start button
                    var stateStartButtonNebul = document.createElement('button');
                    stateStartButtonNebul.className = 'btn btn-success btn-sm';
                    stateStartButtonNebul.innerText = 'Start';
                    stateStartButtonNebul.setAttribute('data-key', key);
                    stateStartButtonNebul.addEventListener('click', function() {
                        var key = this.getAttribute('data-key');
                        updateStateNebulStart(key);
                    });

                    // Create state stop button
                    var stateStopButtonNebul = document.createElement('button');
                    stateStopButtonNebul.className = 'btn btn-danger btn-sm ml-2';
                    stateStopButtonNebul.innerText = 'Stop';
                    stateStopButtonNebul.setAttribute('data-key', key);
                    stateStopButtonNebul.addEventListener('click', function() {
                        var key = this.getAttribute('data-key');
                        updateStateNebulStop(key);
                    });

                    tdStateNebul.appendChild(stateStartButtonNebul);
                    tdStateNebul.appendChild(stateStopButtonNebul);
                    row.appendChild(tdStateNebul);

                    var tdAction = document.createElement('td');

                    // Create update button
                    var updateButton = document.createElement('button');
                    updateButton.className = 'btn btn-primary btn-sm mr-2';
                    updateButton.innerText = 'Update';
                    updateButton.setAttribute('data-key', key);
                    updateButton.addEventListener('click', function() {
                        var key = this.getAttribute('data-key');
                        openUpdateNebulModal(key, data[key]);
                    });

                    // Create delete button
                    var deleteButton = document.createElement('button');
                    deleteButton.className = 'btn btn-danger btn-sm ml-2';
                    deleteButton.innerText = 'Delete';
                    deleteButton.setAttribute('data-key', key);
                    deleteButton.addEventListener('click', function() {
                        var key = this.getAttribute('data-key');
                        deleteDataNebul(key);
                    });

                    tdAction.appendChild(updateButton);
                    tdAction.appendChild(deleteButton);
                    row.appendChild(tdAction);

                    tbody.appendChild(row);
                    counter++;
                }
            }

            table.appendChild(tbody);
            checkinList.appendChild(table);
        }

        function updateStateNebulStart(key) {
            // Update the node /data/key/state with value "start" in Firebase
            firebase.database().ref('data_nebul/' + key + '/state').set('start')
            .then(() => {
                // Show success message with SweetAlert
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: 'Node state updated to "start" successfully'
                });
            })
            .catch((error) => {
                // Show error message with SweetAlert
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Error updating node state: ' + error.message
                });
            });
        }

        function updateStateNebulStop(key) {
            // Update the node /data/key/state with value "start" in Firebase
            firebase.database().ref('data_nebul/' + key + '/state').set('stop')
            .then(() => {
                // Show success message with SweetAlert
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: 'Node state updated to "stop" successfully'
                });
            })
            .catch((error) => {
                // Show error message with SweetAlert
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Error updating node state: ' + error.message
                });
            });
        }

        function deleteDataNebul(key) {
            // Confirm before deleting
            if (confirm('Are you sure you want to delete this entry?')) {
                // Delete data from Firebase
                firebase.database().ref('/data_nebul/' + key).remove()
                    .then(function() {
                        $('#addModal').modal('hide');
                        Swal.fire(
                            'Deleted!',
                            'Data deleted successfully!',
                            'success'
                        );
                        refreshCheckInList();
                    }).catch(function(error) {
                        Swal.fire(
                            'Error!',
                            'Error Delete Data! ' + error.message,
                            'error'
                        );
                    });
            }
        }

        function refreshCheckInList() {
            // Fetch data from Firebase and update the list
            firebase.database().ref('/data_nebul/').once('value', function(snapshot) {
                var data = snapshot.val();
                updateCheckInList(data);
            });
        }

        // Listen for changes in Check Out node
        var checkinRef = database.ref('/data_nebul/');
        checkinRef.on('value', (snapshot) => {
            var data = snapshot.val();
            updateCheckInList(data);
        });

    </script>

    <!-- Add Modal -->
    <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addModalLabel">Add Data Infus</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group">
                            <input type="hidden" class="form-control" id="addLastUpdate" value="0000-00-00T00:00:00">
                            <input type="hidden" class="form-control" id="addPersentaseBaterai" value="0">
                            <input type="hidden" class="form-control" id="addPersentaseInfus" value="0">
                            <input type="hidden" class="form-control" id="addTeganganBaterai" value="0">
                            <input type="hidden" class="form-control" id="addAlert" value="-">
                        </div>
                        <div class="form-group">
                            <label for="addNomorInfus">Nomor Infus</label>
                            <input type="text" class="form-control" id="addNomorInfus">
                        </div>
                        <div class="form-group">
                            <label for="addNamaPasienInfus">Pilih Pasien</label>
                            <select class="form-control" id="addNamaPasienInfus">
                            <option value="">Select Pasien</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="addLokasi">Lokasi Infus</label>
                            <input type="text" class="form-control" id="addLokasi">
                        </div>
                        <div class="form-group">
                            <label for="addKapasitas">Kapasitas Infus (mL)</label>
                            <input type="text" class="form-control" id="addKapasitas">
                        </div>
                        <div class="form-group">
                            <label for="addMLPerDetik">Tetes /menit</label>
                            <input type="text" class="form-control" id="addMLPerDetik">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="addData()">Add</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="addNebulModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addModalLabel">Add Data Nebul</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form>
                <div class="form-group">
                    <input type="hidden" class="form-control" id="addLastUpdate" value="0000-00-00T00:00:00">
                    <input type="hidden" class="form-control" id="addPersentaseNebul" value="0">
                </div>
                <div class="form-group">
                    <label for="addNomorNebul">Nomor Nebul</label>
                    <input type="text" class="form-control" id="addNomorNebul">
                </div>
                <div class="form-group">
                    <label for="addLokasiNebul">Lokasi Nebul</label>
                    <input type="text" class="form-control" id="addLokasiNebul">
                </div>
                <div class="form-group">
                    <label for="addSetWaktu">Set Waktu</label>
                    <input type="text" class="form-control" id="addSetWaktu">
                </div>
                <div class="form-group">
                    <label for="addNamaPasien">Pilih Pasien</label>
                    <select class="form-control" id="addNamaPasien">
                    <option value="">Select Pasien</option>
                    </select>
                </div>
                <div class="form-group">
                    <input type="hidden" class="form-control" id="addStatusNebul" value="-">
                    <input type="hidden" class="form-control" id="addSisaWaktu" value="-">
                </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="addDataNebul()">Add</button>
            </div>
            </div>
        </div>
    </div>

    <!-- Update Modal -->
    <div class="modal fade" id="updateModal" tabindex="-1" role="dialog" aria-labelledby="updateModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="updateModalLabel">Update Data Infus</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group">
                            <label for="updateLokasi">Lokasi Infus</label>
                            <input type="text" class="form-control" id="updateLokasi">
                        </div>
                        <div class="form-group">
                            <label for="updateKapasitas">Kapasitas Infus (mL)</label>
                            <input type="text" class="form-control" id="updateKapasitas">
                        </div>
                        <div class="form-group">
                            <label for="updateMLPerDetik">Tetes /menit</label>
                            <input type="text" class="form-control" id="updateMLPerDetik">
                        </div>
                        <div class="form-group">
                            <label for="updateNamaPasienInfus">Pilih Pasien</label>
                            <select class="form-control" id="updateNamaPasienInfus">
                                <option value="">Select Pasien</option>
                            </select>
                        </div>
                        <input type="hidden" id="updateKey">
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="updateData()">Update</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="updateNebulModal" tabindex="-1" role="dialog" aria-labelledby="updateModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="updateModalLabel">Update Data Nebul</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group">
                            <label for="updateNomorNebul">Nomor Nebul</label>
                            <input type="text" class="form-control" id="updateNomorNebul">
                        </div>
                        <div class="form-group">
                            <label for="updateLokasiNebul">Lokasi Nebul</label>
                            <input type="text" class="form-control" id="updateLokasiNebul">
                        </div>
                        <div class="form-group">
                            <label for="updateSetWaktu">Update Set Waktu</label>
                            <input type="text" class="form-control" id="updateSetWaktu">
                        </div>
                        <div class="form-group">
                            <label for="updateNamaPasien">Pilih Pasien</label>
                            <select class="form-control" id="updateNamaPasien">
                                <option value="">Select Pasien</option>
                            </select>
                        </div>
                        <input type="hidden" id="updateKeyNebul">
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="updateDataNebul()">Update</button>
                </div>
            </div>
        </div>
    </div>
</body>

</html>

<?php
}
else {
    header("location:../index.php");
    exit();
}
?>