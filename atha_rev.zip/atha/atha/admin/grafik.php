<?php
// Aktifkan session
session_start();

if($_SESSION['status'] == "login") {
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>AthaApps - Dashboard Grafik</title>

    <!-- Custom fonts for this template-->
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../css/sb-admin-2.min.css" rel="stylesheet">
    <!-- Firebase App (the core Firebase SDK) is always required and must be listed first -->
    <script src="https://www.gstatic.com/firebasejs/8.6.8/firebase-app.js"></script>
    <!-- Add Firebase products that you want to use -->
    <script src="https://www.gstatic.com/firebasejs/8.6.8/firebase-database.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-dark sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
                <div class="sidebar-brand-text mx-3">Monitoring Infus dan Nebul <sup></sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="kelolaInfus.php">
                    <i class="fas fa-fw fa-pen"></i>
                    <span>Kelola Infus dan Nebul</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="kelolaPasien.php">
                    <i class="fas fa-fw fa-user"></i>
                    <span>Kelola Pasien</span></a>
            </li>

            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="grafik.php">
                    <i class="fas fa-fw fa-chart-bar"></i>
                    <span>Grafik</span></a>
            </li>

            <hr class="sidebar-divider d-none d-md-block">

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"></span>
                                <img class="img-profile rounded-circle" src="../img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="logout.php" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Grafik Monitoring</h1>
                    </div>
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h5 mb-0 text-gray-800">Monitoring Infus 001</h1>
                    </div>

                    <div class="row">
                        <!-- Temperature Card -->
                        <div class="col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Waktu Infus</div>
                                            <div class="chart-area">
                                                <canvas id="kapasitasInfusChart"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Ph Card -->
                        <div class="col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Persentase Baterai</div>
                                            <div class="chart-area">
                                                <canvas id="persentaseBateraiChart"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Temperature Card -->
                        <!-- <div class="col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Persentase Infus</div>
                                            <div class="chart-area">
                                                <canvas id="persentaseInfusChart"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> -->

                        <!-- Ph Card -->
                        <!-- <div class="col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Tegangan Baterai</div>
                                            <div class="chart-area">
                                                <canvas id="teganganBateraiChart"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> -->
                    </div>

                </div>
<br><br>
                <div class="container-fluid">
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h5 mb-0 text-gray-800">Monitoring Nebul</h1>
                    </div>

                    <div class="row">
                        <!-- Temperature Card -->
                        <!-- <div class="col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Waktu Berjalan Nebul</div>
                                            <div class="chart-area">
                                                <canvas id="kapasitasNebulChart"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> -->

                        <!-- Ph Card -->
                        <div class="col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Waktu Nebul</div>
                                            <div class="chart-area">
                                                <canvas id="persentaseNebulChart"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; 2024</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Firebase Configuration and Initialization -->
    <script>
        // Your web app's Firebase configuration
        var firebaseConfig = {
            apiKey: "AIzaSyBH0AunCay59AUa2-2781ArY9XJ-p6GuUs",
            authDomain: "athaapps.firebaseapp.com",
            projectId: "athaapps",
            storageBucket: "athaapps.appspot.com",
            messagingSenderId: "894226660912",
            appId: "1:894226660912:web:e3f48c6e6d05456b6477f5"
        };

        // Initialize Firebase
        firebase.initializeApp(firebaseConfig);

        // Declare global variables for Chart.js instances
        let kapasitasInfusChart, persentaseBateraiChart, persentaseInfusChart, teganganBateraiChart, kapasitasNebulChart, persentaseNebulChart;

        // Function to fetch data from Firebase and update the charts
        function fetchDataAndUpdateCharts() {
            // Fetch data for Kapasitas Infus
            const dbRefKapasitasInfus = firebase.database().ref('grafik/infus001/kapasitas_grafik');
            dbRefKapasitasInfus.on('value', (snapshot) => {
                const data = snapshot.val();
                const kapasitasInfusData = [];
                const timestamps = [];
                for (let key in data) {
                    const entry = data[key];
                    kapasitasInfusData.push(entry.kapasitas);
                    timestamps.push(new Date(entry.timestamp).toLocaleString());
                }
                updateChart(kapasitasInfusChart, kapasitasInfusData, timestamps);
            });

            // Fetch data for Persentase Baterai Infus
            const dbRefPersentaseBaterai = firebase.database().ref('grafik/infus001/persentase_baterai_grafik');
            dbRefPersentaseBaterai.on('value', (snapshot) => {
                const data = snapshot.val();
                const persentaseBateraiData = [];
                const timestamps = [];
                for (let key in data) {
                    const entry = data[key];
                    persentaseBateraiData.push(entry.persentase_baterai);
                    timestamps.push(new Date(entry.timestamp).toLocaleString());
                }
                updateChart(persentaseBateraiChart, persentaseBateraiData, timestamps);
            });

            // Fetch data for Persentase Infus
            const dbRefPersentaseInfus = firebase.database().ref('grafik/infus001/persentase_infus_grafik');
            dbRefPersentaseInfus.on('value', (snapshot) => {
                const data = snapshot.val();
                const persentaseInfusData = [];
                const timestamps = [];
                for (let key in data) {
                    const entry = data[key];
                    persentaseInfusData.push(entry.persentase_infus);
                    timestamps.push(new Date(entry.timestamp).toLocaleString());
                }
                updateChart(persentaseInfusChart, persentaseInfusData, timestamps);
            });

            // Fetch data for Tegangan Baterai Infus
            const dbRefTeganganBaterai = firebase.database().ref('grafik/infus001/tegangan_baterai_grafik');
            dbRefTeganganBaterai.on('value', (snapshot) => {
                const data = snapshot.val();
                const teganganBateraiData = [];
                const timestamps = [];
                for (let key in data) {
                    const entry = data[key];
                    teganganBateraiData.push(entry.tegangan_baterai);
                    timestamps.push(new Date(entry.timestamp).toLocaleString());
                }
                updateChart(teganganBateraiChart, teganganBateraiData, timestamps);
            });

            // Fetch data for kapasitas Nebul
            // const dbRefKapasitasNebul = firebase.database().ref('grafik/nebul001/waktu_berjalan_grafik');
            // dbRefKapasitasNebul.on('value', (snapshot) => {
            //     const data = snapshot.val();
            //     const kapasitasNebulData = [];
            //     const timestamps = [];
            //     for (let key in data) {
            //         const entry = data[key];
            //         kapasitasNebulData.push(entry.waktu_berjalan);
            //         timestamps.push(new Date(entry.timestamp).toLocaleString());
            //     }
            //     updateChart(kapasitasNebulChart, kapasitasNebulData, timestamps);
            // });

            // Fetch data for Persentase Nwbul
            const dbRefPersentaseNebul = firebase.database().ref('grafik/nebul001/persentase_nebul_grafik');
            dbRefPersentaseNebul.on('value', (snapshot) => {
                const data = snapshot.val();
                const persentaseNebulData = [];
                const timestamps = [];
                for (let key in data) {
                    const entry = data[key];
                    persentaseNebulData.push(entry.persentase_nebul);
                    timestamps.push(new Date(entry.timestamp).toLocaleString());
                }
                updateChart(persentaseNebulChart, persentaseNebulData, timestamps);
            });
        }

        // Function to update the chart with new data
        function updateChart(chart, data, labels) {
            if (!chart) {
                console.error('Chart object is undefined');
                return;
            }
            chart.data.labels = labels;
            chart.data.datasets[0].data = data;
            chart.update();
        }

        // Initialize charts after DOM is fully loaded
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize Chart.js instances for each chart
            const ctxKapasitasInfus = document.getElementById('kapasitasInfusChart').getContext('2d');
            kapasitasInfusChart = new Chart(ctxKapasitasInfus, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [{
                        label: 'Waktu Infus',
                        data: [],
                        borderColor: 'rgba(75, 192, 192, 1)',
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });

            const ctxPersentaseBaterai = document.getElementById('persentaseBateraiChart').getContext('2d');
            persentaseBateraiChart = new Chart(ctxPersentaseBaterai, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [{
                        label: 'Persentase Baterai',
                        data: [],
                        borderColor: 'rgba(54, 162, 235, 1)',
                        backgroundColor: 'rgba(54, 162, 235, 0.2)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });

            // const ctxPersentaseInfus = document.getElementById('persentaseInfusChart').getContext('2d');
            // persentaseInfusChart = new Chart(ctxPersentaseInfus, {
            //     type: 'line',
            //     data: {
            //         labels: [],
            //         datasets: [{
            //             label: 'Persentase Infus',
            //             data: [],
            //             borderColor: 'rgba(255, 206, 86, 1)',
            //             backgroundColor: 'rgba(255, 206, 86, 0.2)',
            //             borderWidth: 1
            //         }]
            //     },
            //     options: {
            //         scales: {
            //             y: {
            //                 beginAtZero: true
            //             }
            //         }
            //     }
            // });

            // const ctxTeganganBaterai = document.getElementById('teganganBateraiChart').getContext('2d');
            // teganganBateraiChart = new Chart(ctxTeganganBaterai, {
            //     type: 'line',
            //     data: {
            //         labels: [],
            //         datasets: [{
            //             label: 'Tegangan Baterai',
            //             data: [],
            //             borderColor: 'rgba(153, 102, 255, 1)',
            //             backgroundColor: 'rgba(153, 102, 255, 0.2)',
            //             borderWidth: 1
            //         }]
            //     },
            //     options: {
            //         scales: {
            //             y: {
            //                 beginAtZero: true
            //             }
            //         }
            //     }
            // });

            // const ctxKapasitasNebul = document.getElementById('kapasitasNebulChart').getContext('2d');
            // kapasitasNebulChart = new Chart(ctxKapasitasNebul, {
            //     type: 'line',
            //     data: {
            //         labels: [],
            //         datasets: [{
            //             label: 'Waktu Berjalan Nebul',
            //             data: [],
            //             borderColor: 'rgba(255, 99, 132, 1)',
            //             backgroundColor: 'rgba(255, 99, 132, 0.2)',
            //             borderWidth: 1
            //         }]
            //     },
            //     options: {
            //         scales: {
            //             y: {
            //                 beginAtZero: true
            //             }
            //         }
            //     }
            // });

            const ctxPersentaseNebul = document.getElementById('persentaseNebulChart').getContext('2d');
            persentaseNebulChart = new Chart(ctxPersentaseNebul, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [{
                        label: 'Waktu Nebul',
                        data: [],
                        borderColor: 'rgba(255, 99, 132, 1)',
                        backgroundColor: 'rgba(255, 99, 132, 0.2)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });

            // Fetch data and update charts
            fetchDataAndUpdateCharts();
        });
    </script>

    <!-- Bootstrap core JavaScript-->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="../vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="../js/demo/chart-area-demo.js"></script>
    <script src="../js/demo/chart-pie-demo.js"></script>

    <script src="../js/firebase.js"></script>



</body>

</html>
<?php
}
else {
    header("location:login.php");
}
?>